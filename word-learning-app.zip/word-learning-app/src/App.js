import React, { useState } from 'react';
import axios from 'axios';
import './App.css';
// import Button from './Button';

function App() {
  const [word, setWord] = useState('');
  const [definition, setDefinition] = useState('');
  const [summary, setSummary] = useState('');
  const [example, setExample] = useState('');
  const [imageSrc, setImage] = useState('');
  // const [results,setRes] = useState('');  
  const [loading, setLoading] = useState(false);
  const [source, setSource] = useState('');
  const [base64Image,setBase64Image] = useState('')

  const handleWordChange = (event) => {
    setWord(event.target.value);
  };

  const handleSubmit = async () => {
    // 这里您需要添加代码来调用后端API获取单词解释和图片
    setLoading(true); // 开始加载
    try{
      
      const response = await axios.post('http://localhost:5000/get-word-info', { word: word });  
      // const response = await axios.post('http://localhost:8080/chat', { word: word });
    console.log(response.data.word_info);
     const  word_info = JSON.parse(response.data.word_info);
     console.log(word_info,"解析后的json数据");
     const {  definition, examples, summary } = word_info;   
     console.log(response.data.source,"数据来源");
     const source =  response.data.source;

      setDefinition(definition);
      setSummary(summary);
      setExample(examples); // 注意这里使用复数形式
      setSource(source)
      console.log("Fetched and parsed data:", {  definition, examples, summary });

      //  showRes(); // 假设你想要立即显示一个单词列表，你可以在这里调用showRes
      
    // 请求图片并等待完成
    const imageBase64 = await showImg();

      console.log(source,"source来源是");
      if (source==="api"&& base64Image) {
         // 保存数据
      await saveWordInfo(word, { definition, examples, summary }, imageBase64);
      console.log("只有在source是api，即通过请求得到数据的情况下，才进行存储，储存完成");
      }
     
      setLoading(false); // 结束加载，完成保存

    } catch(error){
      setLoading(false); // 确保加载状态被清除
      handleError(error);
    }
    
  };

  const saveWordInfo = async (word, data, imageBase64) => {
    try {
      const response = await axios.post('http://localhost:5000/save-word-info', {
        concept: word,
        data: data,
        image_data: imageBase64
      });
      console.log('Data saved successfully:', response.data);
    } catch (error) {
      console.error('Error saving data:', error);
      alert('Failed to save data. Please try again.');
    }
  };

  const handleError = (error) => {
    console.error('Error:', error);
    if (error.response && error.response.status === 401) {
      window.location.href = '/login'; // Redirect to login
    } else {
      alert('An error occurred. Please try again.');
    }
  };

  // const showRes = async()=>{
  //     axios.get('http://localhost:8080/words')
  // .then(response => {
  //   // 处理数据
  //   console.log(response.data);
  //   setRes(response.data)
   
  // })
  // .catch(error => {
  //   console.error('Error fetching words', error);
  // });
  // }

  const showImg = async()=>{
    try {
      const response = await axios.post('http://localhost:5000/generate-image', { word: word });
      const imageBase64 = response.data.image_data; // 直接从响应中取得数据
      setBase64Image(imageBase64);  // 更新状态
      setImage(`data:image/png;base64,${imageBase64}`); // 更新状态
      return imageBase64;  // 返回新的图片数据
    } catch (error) {
      console.error("Error fetching the image:", error);
      return "";  // 发生错误时返回空字符
    }
  }

  return (
    <div className="App">
      <header className="App-header">
        <input type="text" value={word} onChange={handleWordChange} placeholder="输入单词" />
        <button onClick={handleSubmit} disabled={loading}>{loading ? 'Loading...' : '提交'}</button>
        {/* <button onClick={showRes}>成果</button> */}

        <button onClick={showImg} disabled={loading} >{loading ? 'Loading...' : '图片'}</button>
        {imageSrc && <img src={imageSrc} alt="Generated from word" />}
        {definition && <p>definition:{definition}</p>}
        {summary && <p>summary:{summary}</p>}
        {example  && example.length>0 && (
          <ul>
            examples:
            {
              example.map((item)=>(
                <li>{item}</li>
              ))
            }
          </ul>
        )}
         {source && <h5>Data Source: {source === 'cache' ? '来自缓存' : '即时查询'}</h5>}
        {/* {image && <img src={image} alt="Word depiction" />} */}
        
        {/* {results && results.length > 0 && (
        <ul>
          {results.map((item) => (
            <li key={item.id}>
             {item.id} Word: {item.word}, 

            </li>
          ))}
        </ul>
      )} */}
       {/* {source && <p>Data Source: {source === 'cache' ? '来自缓存' : '即时查询'}</p>} */}
      </header>
    </div>
  );
}

export default App;
