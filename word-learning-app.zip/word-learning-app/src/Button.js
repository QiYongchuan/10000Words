import { Card } from "antd";

function Button(){
  return(
    <div>
    <input></input>
    <button >  </button>
    <Card></Card>
    </div>
    
  )
}
export default Button