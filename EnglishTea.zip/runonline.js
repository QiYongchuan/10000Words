

const apiUrl = 'https://api.takomo.ai/c2824d36-8bc3-4c62-a37c-9a15ea4944ad';
const token = 'tk_f70abb967e79da40e46599f83aa31d269e4eca0a3b121d953d5442e1e39301055581648d27cad9d2d5ba27353815d37f';
// const fetch = require('node-fetch');

const requestData = {
  "Text_7kq2": "China"
};

fetch(apiUrl, {
  method: 'POST',
  headers: {
    'Content-Type': 'application/json',
    'Authorization': `Bearer ${token}`
  },
  body: JSON.stringify(requestData),
})
  .then(response => {
    if (!response.ok) {
      throw new Error(`请求失败，状态码：${response.status}`);
    }
    return response.json();
  })
  .then(data => {
    console.log('推断创建成功：', data);
     // 解构data对象中的属性
     const { id, createdAt, status, data: innerData } = data;

      // 在这里可以使用解构后的属性
      console.log('ID：', id);
      console.log('创建时间：', createdAt);
      console.log('状态：', status);
      if(innerData){
        console.log('内部数据：', innerData);
       
        // 继续解构 innerData 对象中的属性
        const { Image_2roa, Text_b2mo } = innerData;

        // 解构 Image_2roa 对象中的属性
        const { type: imageType, downloadUrl: imageUrl } = Image_2roa;

        // 解构 Text_b2mo 对象中的属性
        const { type: textType, downloadUrl: textDownloadUrl } = Text_b2mo;

        console.log('图像类型：', imageType);
        console.log('图像下载链接：', imageUrl);

        console.log('文本类型：', textType);
        console.log('文本下载链接：', textDownloadUrl);
              }
  })
  .catch(error => {
    console.error('发生错误了：', error);
  });

