.then(data => {
  console.log('推断创建成功：', data);
  // 解构 data 对象中的属性
  const { id, createdAt, status, data: innerData } = data;

  // 在这里可以使用解构后的属性
  console.log('ID：', id);
  console.log('创建时间：', createdAt);
  console.log('状态：', status);

  if (innerData) {
    console.log('内部数据存在：', innerData);

    // 继续解构 innerData 对象中的属性
    if (innerData.Image_2roa) {
      console.log("Image_2roa存在:", innerData.Image_2roa);

      // 解构 Image_2roa 对象中的属性
      const { type: imageType, downloadUrl: imageUrl } = innerData.Image_2roa;
      console.log('图像类型：', imageType);
      console.log('图像下载链接：', imageUrl);
    } else {
      console.log("Image_2roa不存在");
    }

    if (innerData.Text_b2mo) {
      console.log("Text_b2mo存在:", innerData.Text_b2mo);

      // 解构 Text_b2mo 对象中的属性
      const { type: textType, downloadUrl: textDownloadUrl } = innerData.Text_b2mo;
      console.log('文本类型：', textType);
      console.log('文本下载链接：', textDownloadUrl);
    } else {
      console.log("Text_b2mo不存在");
    }

  } else {
    console.log('内部数据不存在或为空。');
  }
})
