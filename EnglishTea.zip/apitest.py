from flask import Flask, request, jsonify
from flask_cors import CORS  # 导入 CORS
import requests,json
from openai import OpenAI
import os
import logging,time

app = Flask(__name__)
CORS(app)  # 启用 CORS
logging.basicConfig(level=logging.INFO)

# API_URL = "https://api.takomo.ai/c2824d36-8bc3-4c62-a37c-9a15ea4944ad"
# BEARER_TOKEN = "tk_f70abb967e79da40e46599f83aa31d269e4eca0a3b121d953d5442e1e39301055581648d27cad9d2d5ba27353815d37f"  # 替换为您的 Bearer Token

API_URL = "https://api.takomo.ai/4e51b1c4-bc6d-47a8-a06b-f1b985ff7f00"  # 双线
BEARER_TOKEN ="tk_d40b27e4ae4f5498b875498d2bb9e12bb5a0e2c70cd1e711dcd525501fdb74cb0f719f24c15117928c8fe914cc7e20cb"  # 双线


user_input = 'wonderful'

#     # 准备 API 请求头部和数据
headers = {
        'Authorization': f'Bearer {BEARER_TOKEN}',
        'Content-Type': 'application/json'
    }
data = {
        "Text_7kq2": user_input
    }

    # 发送请求到第三方 API
   
response = requests.post(API_URL, json=data, headers=headers)
response.raise_for_status()  # 检查请求是否成功

result = json.loads(response.text)
statuscode = response.status_code
print(statuscode)

if response.status_code == 201:
    print("post 请求成功")
    print(f"结果是{result}")
    id = result["id"]
    print(f"id={id}")
    # 设置请求的URL
    url = f"https://api.takomo.ai/inferences/{id}"

    # 设置请求头

    # 发送GET请求
    response = requests.get(url, headers=headers)

# 检查响应并处理
    if response.status_code == 200:
        # 处理成功的响应，例如打印响应的内容
        print(response.json())

        response_pre = response.json()
        max_retries = 10  # 设置最大重试次数
        retry_interval = 2  # 设置每次重试间隔秒数

        for _ in range(max_retries):
            response_data = response.json()

            # 当状态为successful时停止重试
            if response_data.get('status') == 'successful':
                print(response_data)  # 打印最终结果
                break

            # # 如果状态不是queued和processing，也停止重试
            # if response_data.get('status') not in ['queued', 'processing']:
            #     print(response_data.get('status'))
            #     print("Unexpected status:", response_data.get('status'))
            #     break

            time.sleep(retry_interval)  # 等待一段时间再次尝试
            print('间隔一段时间再发请求')
            response = requests.get(url, headers=headers)  # 重新发送GET请求

            if response.status_code != 200:
                print("Error:", response.status_code)
                break

    else:
        # 处理错误情况
        print(f"Error_status_code is: {response.status_code}")
        print(response.json())

      

    