import requests

# 设置请求的 URL 和头部信息
url = 'https://api.lingyiwanwu.com/v1/chat/completions'
headers = {
    'Authorization': 'Bearer 3595a6fd78f94f19a05477cacd7a723a',  # 替换 $API_KEY 为你的 API 密钥
    'Content-Type': 'application/json'
}

# 准备请求的数据
data = {
    "model": "yi-vl-plus",
    "messages": [
        {
            "role": "user",
            "content": [
                {
                    "type": "image_url",
                    "image_url": {
                         #"url": "https://01-platform-public.oss-cn-beijing.aliyuncs.com/playground/image/573d3017-23ed-4636-9d74-980d4caefb51-0.jpeg" #成功
                        # "url":"c:\Users\亓永传\Desktop\MyRussiaGirls\6db69a2e-28b0-457f-975e-4c57ead441f2.png" # 失败
                      # "url":"https://avatars.githubusercontent.com/u/105039020?v=4"  # 成功
                       "url":"https://store.storeimages.cdn-apple.com/8756/as-images.apple.com/is/delivery-pickup-phone-202103?wid=1138&hei=616&fmt=jpeg&qlt=90&.v=1614798922000"  # 成功
                        #"url":"https://image.baidu.com/search/detail?ct=503316480&z=undefined&tn=baiduimagedetail&ipn=d&word=apple&step_word=&lid=8148813825729622983&ie=utf-8&in=&cl=2&lm=-1&st=undefined&hd=undefined&latest=undefined&copyright=undefined&cs=3681747216,2368168440&os=1480472156,1798951986&simid=3681747216,2368168440&pn=0&rn=1&di=46137345&ln=1737&fr=&fmq=1710482393936_R&fm=&ic=undefined&s=undefined&se=&sme=&tab=0&width=undefined&height=undefined&face=undefined&is=0,0&istype=0&ist=&jit=&bdtype=11&spn=0&pi=0&gsm=1e&objurl=https%3A%2F%2Fstore.storeimages.cdn-apple.com%2F8756%2Fas-images.apple.com%2Fis%2Fdelivery-pickup-phone-202103%3Fwid%3D1138%26hei%3D616%26fmt%3Djpeg%26qlt%3D90%26.v%3D1614798922000&rpstart=0&rpnum=0&adpicid=0&nojc=undefined&dyTabStr=MCwxLDMsMiw2LDQsNSw4LDcsOQ%3D%3D"  失败
                    }
                },
                {
                    "type": "text",
                    # "text": "请描述图片内容"
                     "text": "describe this picture"
                }
            ]
        }
    ],
    "stream": False,
    "max_tokens": 1024
}

# 发送 POST 请求
response = requests.post(url, headers=headers, json=data)

# 打印响应内容
print(response.text)


































# curl --location 'https://api.lingyiwanwu.com/v1/chat/completions' \
# --header 'Authorization: Bearer $API_KEY' \
# --header 'Content-Type: application/json' \
# --data '{
#     "model": "yi-vl-plus",
#     "messages": [
#         {
#             "role": "user",
#             "content": [
#                 {
#                     "type": "image_url",
#                     "image_url": {
#                         "url": "https://01-platform-public.oss-cn-beijing.aliyuncs.com/playground/image/573d3017-23ed-4636-9d74-980d4caefb51-0.jpeg"
#                     }
#                 },
#                 {
#                     "type": "text",
#                     "text": " 请描述图片内容"
#                 }
#             ]
#         }
#     ],
#     "stream": false,
#     "max_tokens": 1024
# }'
