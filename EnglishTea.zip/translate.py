import requests
import json



# url2="https://findmyip.net/api/translate.php"

# text = "吃了吗"



# text_need_translate = '你好啊，李银河'

# url3 = f"https://findmyip.net/api/translate.php?text={text_need_translate}"

# responseds =  requests.get(url3)

# print(responseds.headers['Content-Type'])

# # 检查响应状态码
# if responseds.status_code == 200:
#     # 处理响应
#     translated_text =  json.loads(responseds.text)  # 或者 response.json()，如果返回的是JSON格式
    
    
#     if isinstance(translated_text, dict):
#       print("ttx是字典类型")
#     else:
#       print("ttx不是字典类型")
    
#     print("Translated Text:", translated_text)


#      # 从字典中获取'translate_result'键的值
#     translate_result = translated_text.get('data', {}).get('translate_result','No translate_result found')
#     print("结果：", translate_result )
# else:
#     print("Error:", responseds.status_code)







url = "https://api.deeplx.org/translate"

payload = json.dumps({
  "text": "fhello,world!beautiful,gils",
  "source_lang": "auto",
  "target_lang": "ZH"
})
headers = {
  'Content-Type': 'application/json'
}

response = requests.request("POST", url, headers=headers, data=payload)

print(response.text)

result =json.loads(response.text) 

if isinstance(result, dict):
    print("res是字典类型")
else:
    print("res不是字典类型")


print(f"翻译的结果是:{result.get('data','no result')},可替代的结果是：{result.get('alternatives')},找不到的结果是：{result.get('ss'),'sorry， no results'}")
