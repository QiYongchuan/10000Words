
import requests
import json

import base64
from IPython.display import Image, display

def get_access_token():
    """
    使用 API Key，Secret Key 获取access_token，替换下列示例中的应用API Key、应用Secret Key
    """
    API_key = "Lu42GOnjdo1K3BuU393Vn84u"
    Secreat_key = "HZGXSB3M7QRRyuzGl22qNEyZqJkZu7hM"
        
    url = f"https://aip.baidubce.com/oauth/2.0/token?grant_type=client_credentials&client_id={API_key}&client_secret={Secreat_key}"
    
    payload = json.dumps("")
    headers = {
        'Content-Type': 'application/json',
        'Accept': 'application/json'
    }
    
    response = requests.request("POST", url, headers=headers, data=payload)
    return response.json().get("access_token")


def main():
        
    url = "https://aip.baidubce.com/rpc/2.0/ai_custom/v1/wenxinworkshop/text2image/sd_xl?access_token=" + get_access_token()
    
    payload = json.dumps({
        "prompt": "cat",
        "negative_prompt": "white",
        "size": "1024x1024",
        "steps": 20, 
        "n": 1,
        "sampler_index": "DPM++ SDE Karras" 
    })
    headers = {
        'Content-Type': 'application/json'
    }
    
    response = requests.request("POST", url, headers=headers, data=payload)
    
    print(response)
    response_data = response.json()  # 将响应的JSON内容解析为字典
    base64_string = response_data['data'][0]["b64_image"] # 从字典中获取Base64编码的图片数据

    
    # 假设base64_string是您的Base64编码字符串
    # base64_string = "这里是您的Base64编码内容"
    image_data = base64.b64decode(base64_string)

    # 将解码的图片数据保存为图片文件
    with open("image.png", "wb") as file:
        file.write(image_data)

    # 显示图片
    display(Image(filename="image.png"))
    

if __name__ == '__main__':
    main()
