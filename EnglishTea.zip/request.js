
const apiUrl = 'https://api.takomo.ai/c2824d36-8bc3-4c62-a37c-9a15ea4944ad';
const token = 'tk_f70abb967e79da40e46599f83aa31d269e4eca0a3b121d953d5442e1e39301055581648d27cad9d2d5ba27353815d37f';


const requestData = {
  "Text_7kq2": "China"
};

fetch(apiUrl, {
  method: 'POST',
  headers: {
    'Content-Type': 'application/json',
    'Authorization': `Bearer ${token}`
  },
  body: JSON.stringify(requestData),
})
  .then(response => {
    if (!response.ok) {
      throw new Error(`请求失败，状态码：${response.status}`);
    }
    return response.json();
  })
  .then(data => {
    console.log('推断创建成功：', data);
  })
  .catch(error => {
    console.error('发生错误：', error);
  });
