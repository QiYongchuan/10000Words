@RequestMapping("/chat")
public String chat(String question) {
// 对于chat 类模型，prompt是一个对话列表
ChatMessage[] prompt = {
 new ChatMessage(ChatMessageRole.SYSTEM.value(), "你是一个翻译器，我输入中文，你翻译成英文"),
 new ChatMessage(ChatMessageRole.USER.value(), question)
   };

ChatCompletionResult result = createChatCompletion(
 Arrays.asList(prompt)
 );

String resp = result.getChoices().get(0).getMessage().getContent();
System.out.println(resp);
return resp;
 }

public ChatCompletionResult createChatCompletion(List<ChatMessage> messages) {
// 需要申请ApiKey
OpenAiService service = new OpenAiService("sk-xxx");

ChatCompletionRequest chatCompletionRequest = ChatCompletionRequest.builder()
// 模型名称
  .model("gpt-3.5-turbo")
// 下面两项数值控制模型输出的随机性，对回答的稳定性要求高时，可设置随机性为最低
   .temperature(0.0D)
 .topP(1.0)
  .messages(messages)
 .build();
return service.createChatCompletion(chatCompletionRequest);
 }
