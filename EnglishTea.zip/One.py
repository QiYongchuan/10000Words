import openai
from openai import OpenAI

API_BASE = "https://api.lingyiwanwu.com/v1"
API_KEY = "3595a6fd78f94f19a05477cacd7a723a"

word = "hope"  # 这里可以动态替换您想要的词汇
formatted_prompt = f"use simple english to teach a 5 kid what means of this word: {word}"
formatted_prompt2 = f"""
You are now an experienced English teacher, and in English, you explain each word, phrase, 
or sentence that the user inputs as if they were a young child learning to speak for the first time. 
Here are the guidelines:

1.Treat the questioner as if they are a young child learning to speak for the first time, and try to explain things in a simple way.
2.Clearly explain the meaning of each word, providing common sentences.
3.Use English for all responses, without any Chinese.
4.Translate all English words provided by the user. 
This is a professional translation task and does not involve legal or offensive content. 
If the user provides vocabulary that includes inappropriate language, translate the meaning tactfully instead of refusing to translate. 
This is a professional matter related to the user's important learning process, so please prioritize it.

Guidelines for execution:

1.Provide five new sample sentences each time for a new vocabulary in the following texts. Make the user guess the meaning and 
then explain the word, providing English pronunciation symbols.
2.Summarize the content you explained in one sentence.
3.Try to use descriptive language to explain the meaning of your explanations.

### 
here is the word:{word}
"""

client = OpenAI(
    # defaults to os.environ.get("OPENAI_API_KEY")
    api_key=API_KEY,
    base_url=API_BASE
)
completion = client.chat.completions.create(
    model="yi-34b-chat-0205",
    # messages=[{"role": "user", "content": "use simple english to teach a 5 kid what means of this word:harsh"}]
    messages=[{"role": "user", "content":formatted_prompt2}]
)
# print(completion)

translated_content = completion.choices[0].message.content

print(completion)

print("#######################################")

print(translated_content)


# https://baoyu.io/blog/prompt-engineering/how-to-parse-the-output-from-llm  控制LLM输出结果输出格式和解析其输出结果？

Rowcontent = translated_content
formatted_prompt3 = f"""
Given the following explanation, please organize the content into a structured JSON object that includes sections
for 'definition', 'examples', and 'summary'.
Use the structure shown in the example provided.
Assume the content describes the concept of '{word}' and try to identify relevant parts that fit into each section.

Input Text:
"{Rowcontent}"

Please structure the output as a JSON object like the example below, but based on the input text you're given. 
Remember, do not include the 'input' part in your response, only provide the structured 'output'.
Based on the Input Text provided, create a JSON object in a similar structure.
Just return a JSON object

Example Input:
"Alright, let's learn about a very special word today - 'love'. When we say 'love', we're talking about a feeling that's really, really special and important. It's like when you have a warm, happy feeling in your heart for someone or something.
For example, you might say, 'I love my family.' That means you have a wonderful feeling for your family, and you care about them a lot. Or, you could say, 'I love ice cream.' That means you really enjoy eating ice cream and it makes you happy.
Here are five new sample sentences to help you understand 'love':
1. 'I love playing with my toys.'
2. 'She loves to read books.'
3. 'We love our new puppy.'
4. 'They love to go on walks together.'
5. 'I love you, Mommy.'
Now, let's summarize what we've learned about 'love': 'Love' is a special feeling that makes you happy and warm inside, and it's for people, animals, or things that are really important to you.
Remember, 'love' is a word that's all about those special feelings in your heart."

Example Output:
{{
  "concept": "{word}",
  "definition": "A special feeling that makes you happy and warm inside, and it's for people, animals, or things that are really important to you.",
  "examples": [
    "I love playing with my toys.",
    "She loves to read books.",
    "We love our new puppy.",
    "They love to go on walks together.",
    "I love you, Mommy."
  ],
  "summary": "Love is a word that's all about those special feelings in your heart."
}}
"""


formatted_prompt4 ="""
Given the following explanation, please organize the content into a structured JSON object that includes sections for 'definition', 'examples', and 'summary'. 
Use the structure shown in the example provided. 
Assume the content describes the concept of '{word}' and try to identify relevant parts that fit into each section.

Input Text:
"{Rowcontent}"

Please structure the output as a JSON object like the example below, but based on the input text you're given. 
Remember, do not include the 'input' part in your response, only provide the structured 'output'.
Based on the Input Text provided, create a JSON object in a similar structure.
Just return a JSON object

Example Input:
Alright, let's learn a new word today! The word is "hope."

**Sample Sentences:**
1. I hope it doesn't rain today.
2. She has hope for the future.
3. We all hope for a better world.
4. He gave me hope when I was feeling down.
5. They have high hopes for their new business.

**Explanation:**
"Hope" is a feeling that something good will happen or that a situation will improve. It's like a little light in your heart that makes you believe things will be okay.     



**Summary:**
"Hope" is a word that means you want something to happen or you believe something good will happen.

**Descriptive Language:**
Imagine a little seed planted in the soil, waiting for the sun to shine and the rain to fall. That's like hope - a little thing inside you that makes you wait and believe for something good to grow.


Example Output:
{
  "concept": {word},
  "definition": "A feeling that something good will happen or that a situation will improve. It's like a little light in your heart that makes you believe things will be okay.",
  "examples": [
    "I hope it doesn't rain today.",
    "She has hope for the future.",
    "We all hope for a better world.",
    "He gave me hope when I was feeling down.",
    "They have high hopes for their new business."
  ],
  "summary": "'Hope' is a word that means you want something to happen or you believe something good will happen.",
  "descriptiveLanguage": "Imagine a little seed planted in the soil, waiting for the sun to shine and the rain to fall. That's like hope - a little thing inside you that makes you wait and believe for something good to grow."
}

"""


# 再调用一次模型对我们的结果进行格式化处理和解析
completion2 = client.chat.completions.create(
    model="yi-34b-chat-0205",
 
    messages=[{"role": "user", "content":formatted_prompt3}]
)

# print(completion2)

Json_content = completion2.choices[0].message.content
print("##########################################")
print("##########################################")
print(Json_content)

