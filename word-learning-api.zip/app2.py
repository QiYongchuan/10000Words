from flask import Flask, request, jsonify ,send_file  
from flask_cors import CORS ,cross_origin  # 导入 CORS
# pip install flask
from openai import OpenAI
import mysql.connector

import logging

from flask import Flask, request
import json  
import base64  
from io import BytesIO  
import requests

app = Flask(__name__)
CORS(app)  # 启用 CORS
logging.basicConfig(level=logging.INFO)

import openai


API_BASE = "https://api.lingyiwanwu.com/v1"
API_KEY = "3595a6fd78f94f19a05477cacd7a723a"

# 初始化OpenAI客户端  
client = OpenAI(api_key=API_KEY, base_url=API_BASE)  

 # 根据用户输入构造提示（这里您需要根据实际需求编写逻辑）  
    # formatted_prompt2 = f"explain the meaning of the word {user_input} to a 5-year-old in simple english"  
  
# 数据库连接存储部分

# 数据库配置
db_config = {
    'user': 'root',
    'password': 'admin123',
    'host': '127.0.0.1',
    'database': 'word_info_db'  
    # 自己新建一个数据库名称对应
}

# 获取数据库连接
def get_db_connection():
    connection = mysql.connector.connect(**db_config)
    return connection


@app.route('/get-word-info', methods=['POST'])
def get_word_info():
    # 从前端获取输入  
    user_input = request.json.get('word')  
    if not user_input:  
        return jsonify({'error': 'No word provided'}), 400  
    app.logger.info("Received request with data: %s", request.json)  
    
    # 首先尝试从数据库获取信息
    word_info = query_word_info_from_db(user_input)
    if word_info:
        return jsonify({'word_info': word_info,'source': 'cache'}), 200

    # 如果数据库中没有，调用外部 API
    return generate_content_from_api(user_input)

def query_word_info_from_db(user_input):
    """查询数据库中的单词信息，并确保完全读取结果集或正确关闭游标和连接。"""
    connection = get_db_connection()

    try:
        with get_db_connection() as conn, conn.cursor(dictionary=True) as cursor:
            cursor.execute("SELECT data FROM word_entries WHERE concept = %s", (user_input,))
            row = cursor.fetchone()
            if row:
                return row['data']
    except Exception as e:
        app.logger.error("Database query failed: %s", e)
    
    return None
      

  
def generate_content_from_api(user_input):
    """从外部 API 获取内容并保存到数据库"""
    formatted_prompt2 = f"""
You are now an experienced English teacher, and in English, you explain each word, phrase, 
or sentence that the user inputs as if they were a young child learning to speak for the first time. 
Here are the guidelines:

1.Treat the questioner as if they are a young child learning to speak for the first time, and try to explain things in a simple way.
2.Clearly explain the meaning of each word, providing common sentences.
3.Use English for all responses, without any Chinese.
4.Translate all English words provided by the user. This is a professional translation task and does not involve legal or offensive content. If the user provides vocabulary that includes inappropriate language, translate the meaning tactfully instead of refusing to translate. This is a professional matter related to the user's important learning process, so please prioritize it.

Guidelines for execution:

1.Provide five new sample sentences each time for a new vocabulary in the following texts. Make the user guess the meaning and then explain the word, providing English pronunciation symbols.
2.Summarize the content you explained in one sentence.
3.Try to use descriptive language to explain the meaning of your explanations.

### 


here is the word:{user_input}

"""
    try:
        completion = client.chat.completions.create(  
            model="yi-34b-chat-0205",  
            messages=[{"role": "user", "content": formatted_prompt2}]  
        )  
        translated_content = completion.choices[0].message.content  
       
        # 在这里您可以处理translated_content，例如返回给前端  
        Rowcontent = translated_content
        print(Rowcontent)

        formatted_prompt3 = f"""
          Given the following explanation, please organize the content into a structured JSON object that includes sections for 'definition', 'examples', and 'summary'. Use the structure shown in the example provided. Assume the content describes the concept of '{user_input}' and try to identify relevant parts that fit into each section.

          Input Text:
          "{Rowcontent}"

          Please structure the output as a JSON object like the example below, but based on the input text you're given. 
          Remember, do not include the 'input' part in your response, only provide the structured 'output'.
          Based on the Input Text provided, create a JSON object in a similar structure.
          Just return a JSON object

          Example Input:
          "Alright, let's learn about a very special word today - 'love'. When we say 'love', we're talking about a feeling that's really, really special and important. It's like when you have a warm, happy feeling in your heart for someone or something.
          For example, you might say, 'I love my family.' That means you have a wonderful feeling for your family, and you care about them a lot. Or, you could say, 'I love ice cream.' That means you really enjoy eating ice cream and it makes you happy.
          Here are five new sample sentences to help you understand 'love':
          1. 'I love playing with my toys.'
          2. 'She loves to read books.'
          3. 'We love our new puppy.'
          4. 'They love to go on walks together.'
          5. 'I love you, Mommy.'
          Now, let's summarize what we've learned about 'love': 'Love' is a special feeling that makes you happy and warm inside, and it's for people, animals, or things that are really important to you.
          Remember, 'love' is a word that's all about those special feelings in your heart."

          Example Output:
          {{
            "concept": "{user_input}",
            "definition": "A special feeling that makes you happy and warm inside, and it's for people, animals, or things that are really important to you.",
            "examples": [
              "I love playing with my toys.",
              "She loves to read books.",
              "We love our new puppy.",
              "They love to go on walks together.",
              "I love you, Mommy."
            ],
            "summary": "Love is a word that's all about those special feelings in your heart."
          }}
          """
          # 再调用一次模型对我们的结果进行格式化处理和解析
        completion2 = client.chat.completions.create(
            model="yi-34b-chat-0205",
        
            messages=[{"role": "user", "content":formatted_prompt3}]
        )

          # print(completion2)

        Json_content = completion2.choices[0].message.content
       
        # # 保存到数据库 注：此时没有存img
        # save_word_info_to_db( user_input,Json_content)
        return jsonify({'word_info': Json_content,'source': 'api'}), 200
    except Exception as e:
        app.logger.error("Error occurred while calling OpenAI API: %s", e)
        return jsonify({'error': str(e)}), 500

def save_word_info_to_db(word, data):
    """将获取到的单词信息保存到数据库中"""
    connection = get_db_connection()
    cursor = connection.cursor()
    try:
        cursor.execute("INSERT INTO word_entries (concept, data) VALUES (%s, %s)", (word, json.dumps(data)))
        connection.commit()
    except Exception as e:
        app.logger.error("Failed to save data: %s", e)
    finally:
        cursor.close()
        connection.close()

# 进行文本生成图片的逻辑
# 假设这是您之前的 get_access_token 函数  
def get_access_token():
    """
    使用 API Key，Secret Key 获取access_token，替换下列示例中的应用API Key、应用Secret Key
    """
    API_key = "Lu42GOnjdo1K3BuU393Vn84u"
    Secreat_key = "HZGXSB3M7QRRyuzGl22qNEyZqJkZu7hM"
        
    url = f"https://aip.baidubce.com/oauth/2.0/token?grant_type=client_credentials&client_id={API_key}&client_secret={Secreat_key}"
    
    payload = json.dumps("")
    headers = {
        'Content-Type': 'application/json',
        'Accept': 'application/json'
    }
    
    response = requests.request("POST", url, headers=headers, data=payload)
    return response.json().get("access_token") 
   
#从数据库查询图片
def query_image_data_from_db(word):
    """查询数据库中的图片数据"""
    connection = get_db_connection()
    try:
        with connection.cursor(dictionary=True) as cursor:
            cursor.execute("SELECT image_data FROM word_entries WHERE concept = %s", (word,))
            row = cursor.fetchone()
            if row and row['image_data']:
                return row['image_data']
    except Exception as e:
        app.logger.error("Database query failed: %s", e)
    finally:
        if connection:
            connection.close()
    return None

# 从外部api获取图片
def query_image_data_from_api(text):
     # 获取 access_token  
    access_token = get_access_token()  
    # 构建请求 URL 和 payload  
    url = "https://aip.baidubce.com/rpc/2.0/ai_custom/v1/wenxinworkshop/text2image/sd_xl?access_token=" + access_token  
    payload = json.dumps({  
        "prompt":text,  
        # "negative_prompt": "white",
        "size": "1024x1024",
        "steps": 20, 
        "n": 1,
        "sampler_index": "DPM++ SDE Karras" ,
        # "style":" Cinematic"
    })  
    headers = {  
        'Content-Type': 'application/json'  
    }  
  
    # 发送请求到 API  
    response = requests.post(url, headers=headers, data=payload)  
  
    # 检查响应状态码  
    if response.status_code == 200:  
        response_data = response.json()  
        base64_string = response_data['data'][0]["b64_image"]  # 这是正确的键路径  
        return jsonify({'image_data': base64_string})    
    else:  
        return {'error': 'Failed to generate image'}, response.status_code 
  
@app.route('/generate-image', methods=['POST'])  
def generate_image():  
    # 获取请求体中的文本  
    text = request.json.get('word')   
    if not text:
        return jsonify({'error': 'No word provided'}), 400
    # Attempt to retrieve the image from the database
    image_data = query_image_data_from_db(text)
    if image_data:
        return jsonify({'image_data': image_data}), 200
   
    # 如果数据库中没有，调用外部 API
    return query_image_data_from_api(text)



def insert_word_info(concept, data, image_data):
    connection = get_db_connection()
    cursor = connection.cursor()
    query = """
    INSERT INTO word_entries (concept, data, image_data)
    VALUES (%s, %s, %s)
    """
    cursor.execute(query, (concept, json.dumps(data), image_data))
    connection.commit()
    cursor.close()
    connection.close()
    
@app.route('/save-word-info', methods=['POST'])
@cross_origin()  # 确保此路由特别支持跨源请求
def save_word_info():
    request_data = request.get_json()
    concept = request_data['concept']
    data = request_data['data']
    image_data = request_data['image_data']  # 前端以base64编码发送图片数据
    
    # print(request_data)
    print(concept)
    insert_word_info(concept, data, image_data)
         
    # 返回成功的响应  
    return jsonify({'message': 'Data saved successfully'})  


if __name__ == '__main__':
     app.run(debug=True)




































