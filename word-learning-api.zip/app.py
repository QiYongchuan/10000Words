from flask import Flask, request, jsonify
from flask_cors import CORS  # 导入 CORS
import requests
from openai import OpenAI
import os
import logging
import time

app = Flask(__name__)
CORS(app)  # 启用 CORS
logging.basicConfig(level=logging.INFO)

API_URL = "https://api.takomo.ai/4e51b1c4-bc6d-47a8-a06b-f1b985ff7f00"
BEARER_TOKEN = "tk_f70abb967e79da40e46599f83aa31d269e4eca0a3b121d953d5442e1e39301055581648d27cad9d2d5ba27353815d37f"  # 替换为您的 Bearer Token



@app.route('/get-word-info', methods=['POST'])
def generate_content():
    # 从前端获取输入
    user_input = request.json['word']
    app.logger.info("Received request with data: %s", request.json)
    # 准备 API 请求头部和数据
    headers = {
        'Authorization': f'Bearer {BEARER_TOKEN}',
        'Content-Type': 'application/json'
    }
    data = {
        "Text_7kq2": user_input
    }

    # 发送请求到第三方 API
    try:
        response = requests.post(API_URL, json=data, headers=headers)
        response.raise_for_status()  # 检查请求是否成功
        result = response.json()
        app.logger.info(f"API response: {result}")
         # 这里您可以根据返回的数据结构来调整
         
         
    # 设置请求的URL
        url = f"https://api.takomo.ai/inferences/{id}"

        # 设置请求头

        # 发送GET请求
        response = requests.get(url, headers=headers)
         
         # 检查响应并处理
        if response.status_code == 200:
        # 处理成功的响应，例如打印响应的内容
            print(response.json())

            response_pre = response.json()
            max_retries = 10  # 设置最大重试次数
            retry_interval = 2  # 设置每次重试间隔秒数

            for _ in range(max_retries):
                response_data = response.json()
                # 当状态为successful时停止重试
                if response_data.get('status') == 'successful':
                    print(response_data)  # 打印最终结果
                    image_url = response_data['data']['Image_2roa']['downloadUrl'] if 'Image_2roa' in result['data'] else None
                    text_content = response_data['data']['Text_b2mo'] if 'Text_b2mo' in result['data'] else None

                    return jsonify({
                        'image_url': image_url,
                        'text_content': text_content
                    })
                    break

            # 如果状态不是queued和processing，也停止重试
                if response_data.get('status') not in ['queued', 'processing']:
                    print("Unexpected status:", response_data.get('status'))
                    break

                time.sleep(retry_interval)  # 等待一段时间再次尝试
                response = requests.get(url, headers=headers)  # 重新发送GET请求

                if response.status_code != 200:
                    print("Error:", response.status_code)
                    break

        else:
                # 处理错误情况
                print(f"Error: {response.status_code}")
         
         
         
         
         
         
        # 例如，如果返回的是图片链接或文本内容，您可以按需提取并整理这些信息
        # 示例：提取返回的图片链接和文本内容
        # image_url = result['data']['Image_2roa']['downloadUrl'] if 'Image_2roa' in result['data'] else None
        # text_content = result['data']['Text_b2mo'] if 'Text_b2mo' in result['data'] else None

        # return jsonify({
        #     'image_url': image_url,
        #     'text_content': text_content
        # })
         
        # 处理响应数据
        # ...
    except requests.RequestException as e:
        app.logger.error(f"API request failed: {e}")
        return jsonify({'error': 'API request failed'}), 500
    except Exception as e:
        app.logger.error(f"Server error: {e}")
        return jsonify({'error': 'Internal Server Error'}), 500

if __name__ == '__main__':
     app.run(debug=True)




































#openai版本
# app = Flask(__name__)
# CORS(app)  # 启用 CORS
# # 设置您的 OpenAI API 密钥
# # openai.api_key = os.getenv("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")

# @app.route('/get-word-info', methods=['POST'])
# def get_word_info():
#     word = request.json['word']
    
#      # 获取单词解释
#     try:
#         client = OpenAI(
#       # defaults to os.environ.get("OPENAI_API_KEY")
#         api_key="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",
#         )
#         explanation_response = client.chat.completions.create(
#           messages=[
#               {
#                   "role":"user",
#                   "content":f"Explain the word '{word}' in simple English.",
#               }
#           ],
#          model="gpt-3.5-turbo",
#         )
#         explanation = explanation_response.choices[0].text.strip()
#     except Exception as e:
#         explanation = "Error retrieving word explanation."
#         print("Error:", e)

#     # 暂时使用静态数据来模拟
#     word_info = {
#         "definition": "这里是单词" + word + "的解释:"+ explanation,
#         "image": "image_url_here"  # 替换为图片URL
#     }
    
#     return jsonify(word_info)

# if __name__ == '__main__':
#     app.run(debug=True)
