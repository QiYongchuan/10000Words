
import mysql.connector

db_config = {
    'user': 'root',
    'password': 'admin123',
    'host': '127.0.0.1',
    'database': 'word_info_db',
    'port': 3306
}

def get_db_connection():
    print("Connecting to MySQL database with the following credentials:")
    print(f"User: {db_config['user']}")
    print(f"Password: {db_config['password']}")
    print(f"Host: {db_config['host']}")
    print(f"Database: {db_config['database']}")
    connection = mysql.connector.connect(**db_config)
    return connection




try:
    print("Trying to connect to the database...")
    connection = mysql.connector.connect(**db_config)
    if connection.is_connected():
        print("Connection was successful!")
        print(f"User: {db_config['user']}")
        print(f"Password: {db_config['password']}")
        print(f"Host: {db_config['host']}")
        print(f"Database: {db_config['database']}")
        # 您可以执行一些基本的数据库操作来进一步测试
finally:
    if connection.is_connected():
        connection.close()
        print("Database connection closed.")
